local ModLua = {}

local mapMenu

function ModLua.init()
	mapMenu = Helper.getMenu("MapMenu")
	mapMenu.registerCallback ("createSideBar_on_start", createSideBar_on_start)
	mapMenu.registerCallback ("createInfoFrame_on_menu_infoTableMode", createInfoFrame_on_menu_infoTableMode)
	mapMenu.registerCallback ("createRightBar_on_start", createRightBar_on_start)
	mapMenu.registerCallback ("createInfoFrame2_on_menu_infoModeRight", createInfoFrame2_on_menu_infoModeRight)
end

function createSideBar_on_start(config)
	local isHelloWorldOk
	for _, menuItem in ipairs (config.leftBar) do
		if menuItem.mode == "mode_hello_world_left" then
			isHelloWorldOk = true
		end
	end
	if not isHelloWorldOk then
		local helloWorldButton = {
			name = "Hello World - Left",
			icon = "mapst_information",
			mode = "mode_hello_world_left",
			helpOverlayID = "help_sidebar_hello_world_left",
			helpOverlayText = "Hello World - Left",
		}
		table.insert (config.leftBar, helloWorldButton)
	end
end

function createInfoFrame_on_menu_infoTableMode (infoFrame)
	local menu = mapMenu
	if menu.infoTableMode == "mode_hello_world_left" then
		local ftable = infoFrame:addTable (1, {tabOrder = 1, multiSelect = true})
		local row = ftable:addRow (false)
		row[1]:createText ("Hellow World - Left")
	end
end

function createRightBar_on_start(config)
	local isHelloWorldOk
	for _, menuItem in ipairs (config.rightBar) do
		if menuItem.mode == "mode_hello_world_right" then
			isHelloWorldOk = true
		end
	end
	if not isHelloWorldOk then
		local helloWorldButton = {
			name = "Hello World - Right",
			icon = "mapst_information",
			mode = "mode_hello_world_right",
			helpOverlayID = "help_sidebar_hello_world_right",
			helpOverlayText = "Hello World - Right",
		}
		table.insert (config.rightBar, helloWorldButton)
	end
end

function createInfoFrame2_on_menu_infoModeRight (infoFrame2)
	local menu = mapMenu
	if menu.searchTableMode == "mode_hello_world_right" then
		local ftable = infoFrame2:addTable (1, {tabOrder = 1, multiSelect = true})
		local row = ftable:addRow (false)
		row[1]:createText ("Hellow World - Right")
	end
end

return ModLua
