Install this to: "game\extensions\kuertee_uix_mod_sample".
